create function edit_order_request_id() returns trigger
    language plpgsql
as
$$
 BEGIN
   New.id:=nextval('edit_order_request_SEQ');
   Return NEW;
 END;
 
$$;

alter function edit_order_request_id() owner to postgres;

