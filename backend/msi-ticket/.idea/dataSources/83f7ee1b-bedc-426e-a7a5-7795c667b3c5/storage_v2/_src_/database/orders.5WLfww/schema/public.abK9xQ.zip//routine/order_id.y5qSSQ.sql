create function order_id() returns trigger
    language plpgsql
as
$$
 BEGIN
   New.id:=nextval('order_SEQ');
   Return NEW;
 END;
 
$$;

alter function order_id() owner to postgres;

