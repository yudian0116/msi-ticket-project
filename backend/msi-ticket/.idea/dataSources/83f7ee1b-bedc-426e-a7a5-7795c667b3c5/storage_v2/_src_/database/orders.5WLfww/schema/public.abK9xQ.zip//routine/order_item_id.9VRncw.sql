create function order_item_id() returns trigger
    language plpgsql
as
$$
 BEGIN
   New.id:=nextval('order_item_SEQ');
   Return NEW;
 END;
 
$$;

alter function order_item_id() owner to postgres;

